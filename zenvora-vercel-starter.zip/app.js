const products = [
      {id:1,name:"The Essential Tailored Coat",category:"Women",colour:"Black",price:1299,image:"https://images.unsplash.com/photo-1539533018447-63fcce2678e3?auto=format&fit=crop&w=700&q=85",tag:"SIGNATURE"},
      {id:2,name:"Relaxed Premium Shirt",category:"Men",colour:"White",price:549,image:"https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=700&q=85",tag:"NEW"},
      {id:3,name:"Sculpted Everyday Sneakers",category:"Shoes",colour:"White",price:899,image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=85",tag:"BESTSELLER"},
      {id:4,name:"Minimal Structured Handbag",category:"Accessories",colour:"Gold",price:999,image:"https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=700&q=85",tag:"LIMITED"},
      {id:5,name:"Modern Silver Statement Top",category:"Women",colour:"Silver",price:699,image:"https://images.unsplash.com/photo-1551163943-3f6a855d1153?auto=format&fit=crop&w=700&q=85",tag:"NEW"},
      {id:6,name:"Classic Black Overshirt",category:"Men",colour:"Black",price:749,image:"https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=700&q=85",tag:"ESSENTIAL"},
      {id:7,name:"Clean Line Leather Loafers",category:"Shoes",colour:"Black",price:1099,image:"https://images.unsplash.com/photo-1531310197839-ccf54634509e?auto=format&fit=crop&w=700&q=85",tag:"SIGNATURE"},
      {id:8,name:"Gold Tone Everyday Detail",category:"Accessories",colour:"Gold",price:399,image:"https://images.unsplash.com/photo-1611652022419-a9419f74343d?auto=format&fit=crop&w=700&q=85",tag:"FINISHING TOUCH"}
    ];
    let activeCategory = "All", activeColour = "All", query = "";
    let cart = JSON.parse(localStorage.getItem("zenvora-demo-cart") || "[]");
    const money = n => new Intl.NumberFormat("da-DK",{style:"currency",currency:"DKK",maximumFractionDigits:0}).format(n);
    const productsEl = document.getElementById("products");
    function renderProducts(){
      const list = products.filter(p =>
        (activeCategory==="All" || p.category===activeCategory || p.colour===activeCategory) &&
        (activeColour==="All" || p.colour===activeColour) &&
        (p.name+" "+p.category+" "+p.colour).toLowerCase().includes(query.toLowerCase())
      );
      productsEl.innerHTML = list.length ? list.map(p=>`
        <article class="product">
          <div class="product-image">
            <img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.style.display='none';this.parentElement.style.background='linear-gradient(145deg,#d8d5ce,#77736b)'">
            <span class="tag">${p.tag}</span>
            <button class="quick-add" onclick="addToCart(${p.id})">Add to bag&nbsp; +</button>
          </div>
          <div class="product-info"><h3>${p.name}</h3>
            <div class="product-meta"><span>${p.category} · ${p.colour}</span><strong>${money(p.price)}</strong></div>
            <div class="swatches"><i class="swatch" style="background:#171717"></i><i class="swatch" style="background:#fff"></i><i class="swatch" style="background:#bfc2c5"></i><i class="swatch" style="background:#b99a5b"></i></div>
          </div>
        </article>`).join("") : '<div class="empty" style="grid-column:1/-1">No pieces found. Try another search or edit.</div>';
    }
    function saveCart(){localStorage.setItem("zenvora-demo-cart",JSON.stringify(cart));renderCart();document.getElementById("cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0)}
    function addToCart(id){const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id,qty:1});saveCart();showToast("Added to your bag")}
    function changeQty(id,delta){const item=cart.find(x=>x.id===id);if(!item)return;item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);saveCart()}
    function removeItem(id){cart=cart.filter(x=>x.id!==id);saveCart()}
    function renderCart(){
      const el=document.getElementById("cartItems");
      if(!cart.length){el.innerHTML='<div class="empty">Your bag is waiting for something special.</div>'}
      else{el.innerHTML=cart.map(x=>{const p=products.find(y=>y.id===x.id);return `<div class="cart-line"><img src="${p.image}" alt=""><div><h4>${p.name}</h4><small>${money(p.price)}</small><div class="qty"><button onclick="changeQty(${p.id},-1)">−</button><span>${x.qty}</span><button onclick="changeQty(${p.id},1)">+</button></div><button class="remove" onclick="removeItem(${p.id})">Remove</button></div><strong style="font-size:11px">${money(p.price*x.qty)}</strong></div>`}).join("")}
      document.getElementById("cartTotal").textContent=money(cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0));
    }
    function showToast(message){const t=document.getElementById("toast");t.textContent=message;t.classList.remove("hidden");clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.add("hidden"),2300)}
    document.querySelectorAll(".subnav button").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".subnav button").forEach(x=>x.classList.remove("active"));b.classList.add("active");activeCategory=b.dataset.filter;renderProducts()}));
    document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");activeColour=b.dataset.colour;renderProducts()}));
    document.getElementById("searchForm").addEventListener("submit",e=>{e.preventDefault();query=document.getElementById("searchInput").value;document.getElementById("shop").scrollIntoView();renderProducts()});
    document.getElementById("searchInput").addEventListener("input",e=>{query=e.target.value;renderProducts()});
    document.getElementById("shopNow").addEventListener("click",()=>document.getElementById("shop").scrollIntoView({behavior:"smooth"}));
    document.getElementById("cartOpen").addEventListener("click",()=>document.getElementById("cartOverlay").classList.remove("hidden"));
    document.getElementById("cartClose").addEventListener("click",()=>document.getElementById("cartOverlay").classList.add("hidden"));
    document.getElementById("cartOverlay").addEventListener("click",e=>{if(e.target.id==="cartOverlay")e.currentTarget.classList.add("hidden")});
    document.getElementById("checkout").addEventListener("click",()=>showToast("Demo only — payment checkout is not connected yet."));
    document.getElementById("loginOpen").addEventListener("click",()=>document.getElementById("loginModal").classList.remove("hidden"));
    async function requestHostAccess(){
      const name=document.getElementById("userName").value.trim()||"Test User";
      const email=document.getElementById("userEmail").value.trim()||"test@zenvora.demo";
      localStorage.setItem("zenvora-demo-user",JSON.stringify({name,email,status:"pending"}));
      document.getElementById("loginModal").classList.add("hidden");
      document.getElementById("waitingModal").classList.remove("hidden");
      document.getElementById("loginOpen").textContent="PENDING";
      try { await fetch("/api/access-request",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,email})}); } catch (_) {}
      checkHostApproval();
    }
    async function checkHostApproval(){
      const statusEl=document.getElementById("waitingStatus");
      try {
        const response=await fetch("/api/access-status",{method:"GET",cache:"no-store"});
        if(response.ok){
          const data=await response.json();
          if(data.status==="approved"){
            const user=JSON.parse(localStorage.getItem("zenvora-demo-user")||"{}");
            localStorage.setItem("zenvora-demo-user",JSON.stringify({...user,status:"approved"}));
            document.getElementById("waitingModal").classList.add("hidden");
            document.getElementById("loginOpen").textContent="MY ACCOUNT";
            showToast("Welcome to ZENVORA!");
            return;
          }
        }
      } catch (_) {}
      statusEl.textContent="Status: Waiting for host approval…";
    }
    document.getElementById("enterStore").addEventListener("click",requestHostAccess);
    document.getElementById("checkApproval").addEventListener("click",checkHostApproval);
    const savedUser=JSON.parse(localStorage.getItem("zenvora-demo-user")||"null");
    if(savedUser && savedUser.status!=="approved"){
      document.getElementById("loginModal").classList.add("hidden");
      document.getElementById("waitingModal").classList.remove("hidden");
      document.getElementById("loginOpen").textContent="PENDING";
      checkHostApproval();
    }
    saveCart();renderProducts();
