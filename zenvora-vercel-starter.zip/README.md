# ZENVORA — Vercel customer storefront

## Files
- `index.html` — customer storefront (must be named index.html)
- `app.js` — storefront interactions
- `vercel.json` — Vercel project configuration

## Deploy with GitHub + Vercel
1. Extract this ZIP on your computer.
2. Create a new GitHub repository named `zenvora`.
3. Upload the **contents** of this folder to the repository root (do not upload the ZIP itself and do not put the files inside another nested `zenvora-vercel` folder).
4. Confirm `index.html`, `app.js`, and `vercel.json` are visible at the top level of the GitHub repository.
5. In Vercel, choose **Add New → Project**, import the `zenvora` GitHub repository, and deploy.
6. Use the default settings. No build command or output directory is required for this static HTML demo.
7. Open the deployment's root URL, e.g. `https://your-project.vercel.app/`.

## Important current limitations
This is the **customer-side classroom demo**. The product photos are loaded from external image URLs, so internet access is needed to display them.
- The cart is stored in that browser's local storage.
- The TEST USER waiting screen is included.
- The `/api/access-request` and `/api/access-status` calls are placeholders for the future backend. This ZIP does **not** include the private admin panel, shared database, real cross-device host approval, payments, or order fulfilment yet.
- Do not treat the browser-only demo as secure authentication. The real approval workflow needs a server-side API plus a database and protected admin login.

If Vercel says the site does not exist, check that `index.html` is at the repository root and that you opened the latest successful deployment URL rather than a repository URL.
